import React, { useState, useMemo, useRef } from "react";
import Papa from "papaparse";
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { Upload, RefreshCw, RotateCcw, CheckCircle2, AlertTriangle } from "lucide-react";

// ---------- palette ----------
const COLORS = {
  bg: "#0A0D14",
  panel: "#11151F",
  panelAlt: "#0D1119",
  border: "#1E2433",
  borderSoft: "#171C29",
  textPrimary: "#F2F4FA",
  textSecondary: "#7C8597",
  textFaint: "#525A6B",
  blue: "#4C6FFF",
  cyan: "#2DD9C5",
  violet: "#9B6BFF",
  amber: "#F5A623",
  pink: "#FF4FA3",
  red: "#FF5C5C",
  green: "#3ECF8E",
};

const MONO = "ui-monospace, SFMono-Regular, Menlo, Consolas, monospace";
const SANS = "ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif";
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const BUCKET_PRESETS = [1, 2, 3, 7, 14, 30];

const pad2 = (n) => String(n).padStart(2, "0");
const toISODate = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const fmtDate = (d) => `${MONTHS[d.getMonth()]} ${d.getDate()}`;
const fmtRange = (start, end) => {
  if (toISODate(start) === toISODate(end)) return fmtDate(start);
  return start.getMonth() === end.getMonth()
    ? `${MONTHS[start.getMonth()]} ${start.getDate()}-${end.getDate()}`
    : `${fmtDate(start)}-${fmtDate(end)}`;
};

// ---------- built-in demo data (daily) ----------
function generateBuiltInDailyData() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const start = new Date(today);
  start.setDate(today.getDate() - 119); // 120 days of history
  const rows = [];
  for (let i = 0; i < 120; i++) {
    const date = new Date(start);
    date.setDate(start.getDate() + i);
    const t = i / 119;
    const dow = date.getDay();
    const weekendFactor = dow === 0 || dow === 6 ? 0.6 : 1;
    const noise = 1 + 0.15 * Math.sin(i * 0.9);
    let spend = Math.round((20 + 200 * Math.pow(t, 1.3)) * weekendFactor * noise);
    spend = Math.max(8, spend);
    let cpl = 30 + 8 * Math.sin(i * 0.4 + 1);
    let leads = Math.max(0, Math.round(spend / cpl));
    if (i === 95) leads = Math.max(1, Math.round(spend / 85)); // a costly day
    if (i === 110) leads = Math.round(leads * 2.6 + 4); // a standout day
    const calendlyLeads = Math.round(leads * 0.62);
    const slpLeads = Math.max(0, leads - calendlyLeads);
    const reach = Math.round(spend * 9 + leads * 80);
    const impressions = Math.round(reach * 1.8);
    const lpViews = Math.round(slpLeads * 3.5 + 12);
    rows.push({ date, spend, leads, calendlyLeads, slpLeads, reach, impressions, lpViews });
  }
  return rows;
}

// ---------- CSV parsing helpers ----------
function toNum(v) {
  if (v === undefined || v === null || v === "") return 0;
  const n = parseFloat(String(v).replace(/[^0-9.\-]/g, ""));
  return isNaN(n) ? 0 : n;
}

function getVal(row, aliases, excludes = []) {
  const keys = Object.keys(row);
  for (const k of keys) {
    const lk = k.toLowerCase().trim();
    if (aliases.includes(lk)) return row[k];
  }
  for (const k of keys) {
    const lk = k.toLowerCase().trim();
    if (excludes.some((e) => lk.includes(e))) continue;
    if (aliases.some((a) => lk.includes(a))) return row[k];
  }
  return undefined;
}

function parseDateValue(v) {
  if (!v) return null;
  const s = String(v).trim();
  let d = new Date(s);
  if (!isNaN(d.getTime())) {
    d.setHours(0, 0, 0, 0);
    return d;
  }
  const m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
  if (m) {
    let [, a, b, y] = m;
    y = y.length === 2 ? "20" + y : y;
    let month = parseInt(a, 10);
    let day = parseInt(b, 10);
    if (month > 12) [month, day] = [day, month];
    d = new Date(parseInt(y, 10), month - 1, day);
    if (!isNaN(d.getTime())) return d;
  }
  return null;
}

function parseRows(data) {
  const rows = [];
  let missingDateCount = 0;
  data.forEach((row) => {
    const keys = Object.keys(row).filter((k) => k && k.trim() !== "");
    if (keys.length === 0) return;
    const dateRaw = getVal(row, ["date", "day", "date range"]);
    const spend = toNum(getVal(row, ["spend", "total spend", "amount spent", "ad spend"]));
    const calendlyLeads = toNum(getVal(row, ["calendly leads", "calendly"]));
    const slpLeads = toNum(getVal(row, ["slp leads", "slp"]));
    const leadsRaw = getVal(row, ["total leads", "leads"], ["calendly", "slp"]);
    const leads = leadsRaw !== undefined ? toNum(leadsRaw) : calendlyLeads + slpLeads;
    const reach = toNum(getVal(row, ["reach", "total reach"]));
    const impressions = toNum(getVal(row, ["impressions", "total impressions"]));
    const lpViews = toNum(
      getVal(row, ["lp views", "landing page views", "landing page visits", "page views"])
    );

    if (!dateRaw && spend === 0 && leads === 0 && reach === 0 && impressions === 0) return;

    const date = parseDateValue(dateRaw);
    if (!date) missingDateCount++;
    rows.push({ date, spend, leads, calendlyLeads, slpLeads, reach, impressions, lpViews });
  });

  if (rows.length === 0) return { rows: [], missingDateCount: 0 };

  const allMissing = rows.every((r) => !r.date);
  if (allMissing) {
    const base = new Date();
    base.setHours(0, 0, 0, 0);
    base.setDate(base.getDate() - rows.length + 1);
    rows.forEach((r, i) => {
      const d = new Date(base);
      d.setDate(base.getDate() + i);
      r.date = d;
    });
  } else {
    rows.forEach((r, i) => {
      if (!r.date) {
        const prev = rows[i - 1] && rows[i - 1].date;
        r.date = prev ? new Date(prev.getTime() + 86400000) : new Date();
      }
    });
  }

  rows.sort((a, b) => a.date - b.date);
  return { rows, missingDateCount: allMissing ? rows.length : missingDateCount };
}

function tryConvertGoogleSheetLink(url) {
  const editMatch = url.match(/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (editMatch && !url.includes("output=csv") && !url.includes("/pub")) {
    const gidMatch = url.match(/gid=([0-9]+)/);
    const gid = gidMatch ? gidMatch[1] : "0";
    return `https://docs.google.com/spreadsheets/d/${editMatch[1]}/export?format=csv&gid=${gid}`;
  }
  return url;
}

// ---------- aggregation ----------
function aggregateByBucket(rows, bucketSize) {
  const buckets = [];
  for (let i = 0; i < rows.length; i += bucketSize) {
    const slice = rows.slice(i, i + bucketSize);
    if (slice.length === 0) continue;
    const sum = (key) => slice.reduce((s, r) => s + r[key], 0);
    buckets.push({
      label: fmtRange(slice[0].date, slice[slice.length - 1].date),
      startDate: slice[0].date,
      endDate: slice[slice.length - 1].date,
      spend: sum("spend"),
      leads: sum("leads"),
      calendlyLeads: sum("calendlyLeads"),
      slpLeads: sum("slpLeads"),
      reach: sum("reach"),
      impressions: sum("impressions"),
      lpViews: sum("lpViews"),
    });
  }
  return buckets;
}

// ---------- metrics ----------
function computeMetrics(filteredDaily, buckets, targetCPL) {
  const totalSpend = filteredDaily.reduce((s, r) => s + r.spend, 0);
  const totalLeads = filteredDaily.reduce((s, r) => s + r.leads, 0);
  const totalReach = filteredDaily.reduce((s, r) => s + r.reach, 0);
  const totalImpressions = filteredDaily.reduce((s, r) => s + r.impressions, 0);
  const calendlyLeads = filteredDaily.reduce((s, r) => s + r.calendlyLeads, 0);
  const slpLeads = filteredDaily.reduce((s, r) => s + r.slpLeads, 0);
  const totalLPViews = filteredDaily.reduce((s, r) => s + (r.lpViews || 0), 0);
  const avgCPL = totalLeads > 0 ? totalSpend / totalLeads : 0;
  const avgLPViews = filteredDaily.length > 0 ? totalLPViews / filteredDaily.length : 0;

  let bestPeriod = null;
  buckets.forEach((b) => {
    if (!bestPeriod || b.leads > bestPeriod.leads) bestPeriod = b;
  });

  let worstCPLPeriod = null;
  let worstCPL = 0;
  buckets.forEach((b) => {
    if (b.leads > 0) {
      const c = b.spend / b.leads;
      if (c > worstCPL) {
        worstCPL = c;
        worstCPLPeriod = b;
      }
    }
  });

  return {
    totalSpend,
    totalLeads,
    totalReach,
    totalImpressions,
    calendlyLeads,
    slpLeads,
    avgCPL,
    avgLPViews,
    daysActive: filteredDaily.length,
    bestPeriod,
    worstCPL,
    worstCPLPeriod,
    targetCPL,
  };
}

const fmtMoney = (n) =>
  `$${(n || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const fmtInt = (n) => Math.round(n || 0).toLocaleString();

// ---------- small UI pieces ----------
function MetricCard({ label, value, sub, subColor, accent }) {
  return (
    <div
      className="rounded-lg p-3 relative overflow-hidden"
      style={{ backgroundColor: COLORS.panel, border: `1px solid ${COLORS.border}` }}
    >
      <div style={{ height: 3, background: accent, position: "absolute", top: 0, left: 0, right: 0 }} />
      <div
        className="uppercase tracking-wider font-medium"
        style={{ color: COLORS.textFaint, fontFamily: MONO, fontSize: 10, marginTop: 2 }}
      >
        {label}
      </div>
      <div className="font-bold mt-1" style={{ color: COLORS.textPrimary, fontFamily: SANS, fontSize: 22, lineHeight: 1.2 }}>
        {value}
      </div>
      {sub && (
        <div className="text-xs mt-1" style={{ color: subColor || COLORS.textSecondary, fontFamily: SANS }}>
          {sub}
        </div>
      )}
    </div>
  );
}

function SummaryStat({ label, value, color }) {
  return (
    <div>
      <div className="uppercase tracking-wider font-medium" style={{ color: COLORS.textFaint, fontFamily: MONO, fontSize: 10 }}>
        {label}
      </div>
      <div className="font-bold mt-1" style={{ color: color || COLORS.textPrimary, fontFamily: SANS, fontSize: 19 }}>
        {value}
      </div>
    </div>
  );
}

// ---------- main component ----------
export default function AdsDashboard() {
  const [dailyData, setDailyData] = useState(() => generateBuiltInDailyData());
  const [fromDate, setFromDate] = useState(() => toISODate(generateBuiltInDailyData()[0].date));
  const [toDate, setToDate] = useState(() => {
    const d = generateBuiltInDailyData();
    return toISODate(d[d.length - 1].date);
  });
  const [bucketSize, setBucketSize] = useState(7);
  const [customBucket, setCustomBucket] = useState("");
  const [csvLink, setCsvLink] = useState("");
  const [targetCPL, setTargetCPL] = useState(42.48);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState({
    type: "success",
    message:
      "Built-in demo data loaded (120 days). Upload a CSV or paste a published Google Sheet CSV link to use your own data.",
  });
  const fileInputRef = useRef(null);

  const loadParsedRows = (parsedResult, sourceLabel) => {
    const { rows, missingDateCount } = parsedResult;
    if (!rows || rows.length === 0) {
      setStatus({ type: "error", message: "No usable rows found in that file. Check the column headers and try again." });
      return;
    }
    setDailyData(rows);
    setFromDate(toISODate(rows[0].date));
    setToDate(toISODate(rows[rows.length - 1].date));
    const note =
      missingDateCount > 0
        ? ` Note: no valid Date column was found, so sequential placeholder dates were used — add a Date column (YYYY-MM-DD) for accurate calendar grouping.`
        : "";
    setStatus({ type: missingDateCount > 0 ? "info" : "success", message: `Loaded ${rows.length} rows from ${sourceLabel}.${note}` });
  };

  const handleFileChange = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    setLoading(true);
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        Papa.parse(ev.target.result, {
          header: true,
          skipEmptyLines: true,
          complete: (res) => {
            loadParsedRows(parseRows(res.data), file.name);
            setLoading(false);
          },
          error: () => {
            setStatus({ type: "error", message: "Could not parse that CSV file." });
            setLoading(false);
          },
        });
      } catch (err) {
        setStatus({ type: "error", message: "Could not parse that CSV file." });
        setLoading(false);
      }
    };
    reader.onerror = () => {
      setStatus({ type: "error", message: "Could not read that file." });
      setLoading(false);
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const handleRefreshLink = async () => {
    const raw = csvLink.trim();
    if (!raw) {
      setStatus({ type: "error", message: "Paste a published Google Sheet CSV link first." });
      return;
    }
    setLoading(true);
    setStatus({ type: "info", message: "Fetching data…" });
    try {
      const url = tryConvertGoogleSheetLink(raw);
      const res = await fetch(url);
      if (!res.ok) throw new Error("bad response");
      const text = await res.text();
      Papa.parse(text, {
        header: true,
        skipEmptyLines: true,
        complete: (parsedRes) => {
          loadParsedRows(parseRows(parsedRes.data), "linked sheet");
          setLoading(false);
        },
        error: () => {
          setStatus({ type: "error", message: "Could not parse the data from that link." });
          setLoading(false);
        },
      });
    } catch (err) {
      setStatus({
        type: "error",
        message:
          "Couldn't fetch that link directly — your browser may be blocking the cross-origin request. In Google Sheets, use File → Share → Publish to web → CSV, copy that link, or download the CSV and use Upload CSV instead.",
      });
      setLoading(false);
    }
  };

  const handleReset = () => {
    setFromDate(toISODate(dailyData[0].date));
    setToDate(toISODate(dailyData[dailyData.length - 1].date));
    setBucketSize(7);
    setCustomBucket("");
  };

  const filteredDaily = useMemo(() => {
    const from = new Date(fromDate + "T00:00:00");
    const to = new Date(toDate + "T23:59:59");
    return dailyData.filter((r) => r.date >= from && r.date <= to);
  }, [dailyData, fromDate, toDate]);

  const effectiveBucket = Math.max(1, parseInt(customBucket, 10) || bucketSize);
  const buckets = useMemo(() => aggregateByBucket(filteredDaily, effectiveBucket), [filteredDaily, effectiveBucket]);
  const metrics = useMemo(() => computeMetrics(filteredDaily, buckets, targetCPL), [filteredDaily, buckets, targetCPL]);

  const pieData = [
    { name: "Calendly Leads", value: metrics.calendlyLeads, color: COLORS.blue },
    { name: "SLP Leads", value: metrics.slpLeads, color: COLORS.cyan },
  ];

  const cplStatus =
    metrics.avgCPL <= targetCPL
      ? { label: "On track", color: COLORS.green }
      : { label: `Above target ${fmtMoney(targetCPL)}`, color: COLORS.red };

  const statusColor = status.type === "success" ? COLORS.green : status.type === "error" ? COLORS.red : COLORS.textSecondary;

  const minDate = dailyData.length ? toISODate(dailyData[0].date) : undefined;
  const maxDate = dailyData.length ? toISODate(dailyData[dailyData.length - 1].date) : undefined;

  return (
    <div className="w-full min-h-screen p-4 md:p-6" style={{ backgroundColor: COLORS.bg, fontFamily: SANS }}>
      {/* header controls */}
      <div className="flex flex-col md:flex-row gap-2 mb-3">
        <input
          type="text"
          value={csvLink}
          onChange={(e) => setCsvLink(e.target.value)}
          placeholder="Paste Google Sheet published CSV link to refresh data…"
          className="flex-1 px-3 py-2 rounded-md text-sm outline-none"
          style={{ backgroundColor: COLORS.panel, border: `1px solid ${COLORS.border}`, color: COLORS.textPrimary }}
        />
        <button
          onClick={handleRefreshLink}
          disabled={loading}
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-md text-sm font-medium"
          style={{ backgroundColor: COLORS.blue, color: "#fff", opacity: loading ? 0.7 : 1 }}
        >
          <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
          Refresh Data
        </button>
        <button
          onClick={() => fileInputRef.current && fileInputRef.current.click()}
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-md text-sm font-medium"
          style={{ backgroundColor: COLORS.panel, border: `1px solid ${COLORS.border}`, color: COLORS.textPrimary }}
        >
          <Upload size={14} />
          Upload CSV
        </button>
        <input ref={fileInputRef} type="file" accept=".csv" onChange={handleFileChange} className="hidden" />
      </div>

      <div className="flex items-center gap-2 mb-4 text-xs" style={{ color: statusColor, fontFamily: SANS }}>
        {status.type === "success" && <CheckCircle2 size={14} />}
        {status.type === "error" && <AlertTriangle size={14} />}
        <span>{status.message}</span>
      </div>

      {/* date range + bucket size + target cpl */}
      <div
        className="flex flex-wrap items-center gap-3 mb-4 px-3 py-2 rounded-md"
        style={{ backgroundColor: COLORS.panelAlt, border: `1px solid ${COLORS.borderSoft}` }}
      >
        <span className="text-xs font-medium" style={{ color: COLORS.textSecondary }}>
          Date range:
        </span>
        <input
          type="date"
          value={fromDate}
          min={minDate}
          max={toDate}
          onChange={(e) => setFromDate(e.target.value)}
          className="text-xs px-2 py-1 rounded-md outline-none"
          style={{ backgroundColor: COLORS.panel, border: `1px solid ${COLORS.border}`, color: COLORS.textPrimary }}
        />
        <span className="text-xs" style={{ color: COLORS.textFaint }}>
          to
        </span>
        <input
          type="date"
          value={toDate}
          min={fromDate}
          max={maxDate}
          onChange={(e) => setToDate(e.target.value)}
          className="text-xs px-2 py-1 rounded-md outline-none"
          style={{ backgroundColor: COLORS.panel, border: `1px solid ${COLORS.border}`, color: COLORS.textPrimary }}
        />

        <div className="flex items-center gap-1.5 ml-2">
          <span className="text-xs font-medium" style={{ color: COLORS.textSecondary }}>
            Group by:
          </span>
          {BUCKET_PRESETS.map((n) => (
            <button
              key={n}
              onClick={() => {
                setBucketSize(n);
                setCustomBucket("");
              }}
              className="text-xs px-2 py-1 rounded-md font-medium"
              style={{
                backgroundColor: !customBucket && bucketSize === n ? COLORS.blue : COLORS.panel,
                border: `1px solid ${!customBucket && bucketSize === n ? COLORS.blue : COLORS.border}`,
                color: !customBucket && bucketSize === n ? "#fff" : COLORS.textSecondary,
              }}
            >
              {n === 7 ? "Week" : n === 30 ? "30D" : n === 1 ? "Day" : `${n}D`}
            </button>
          ))}
          <input
            type="number"
            min="1"
            placeholder="custom"
            value={customBucket}
            onChange={(e) => setCustomBucket(e.target.value)}
            className="w-16 text-xs px-2 py-1 rounded-md outline-none"
            style={{
              backgroundColor: COLORS.panel,
              border: `1px solid ${customBucket ? COLORS.blue : COLORS.border}`,
              color: COLORS.textPrimary,
            }}
          />
          <span className="text-xs" style={{ color: COLORS.textFaint }}>
            days
          </span>
        </div>

        <button
          onClick={handleReset}
          className="flex items-center gap-1 text-xs px-3 py-1 rounded-md font-medium"
          style={{ backgroundColor: COLORS.panel, border: `1px solid ${COLORS.border}`, color: COLORS.textSecondary }}
        >
          <RotateCcw size={12} />
          Reset
        </button>

        <div className="flex items-center gap-2 ml-auto">
          <span className="text-xs font-medium" style={{ color: COLORS.textSecondary }}>
            Target CPL:
          </span>
          <div className="flex items-center gap-1">
            <span className="text-xs" style={{ color: COLORS.textFaint }}>
              $
            </span>
            <input
              type="number"
              step="0.01"
              value={targetCPL}
              onChange={(e) => setTargetCPL(parseFloat(e.target.value) || 0)}
              className="w-16 text-xs px-2 py-1 rounded-md outline-none"
              style={{ backgroundColor: COLORS.panel, border: `1px solid ${COLORS.border}`, color: COLORS.textPrimary }}
            />
          </div>
        </div>

        <span className="text-xs" style={{ color: COLORS.textFaint, fontFamily: MONO }}>
          {filteredDaily.length} days · {buckets.length} periods shown
        </span>
      </div>

      {/* summary bar */}
      <div
        className="rounded-xl p-4 mb-4 flex flex-wrap gap-8"
        style={{ backgroundColor: COLORS.panel, border: `1px solid ${COLORS.border}` }}
      >
        <SummaryStat label="Total Spend" value={fmtMoney(metrics.totalSpend)} color={COLORS.blue} />
        <SummaryStat label="Total Leads" value={fmtInt(metrics.totalLeads)} color={COLORS.green} />
        <SummaryStat label="Avg Cost / Lead" value={fmtMoney(metrics.avgCPL)} color={COLORS.amber} />
        <SummaryStat label="Total Reach" value={fmtInt(metrics.totalReach)} />
        <SummaryStat label="Impressions" value={fmtInt(metrics.totalImpressions)} />
        <SummaryStat label="Best Period" value={metrics.bestPeriod ? metrics.bestPeriod.label : "—"} color={COLORS.textPrimary} />
      </div>

      {/* metric cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-3">
        <MetricCard label="Total Spend" value={fmtMoney(metrics.totalSpend)} sub="selected range" accent={COLORS.pink} />
        <MetricCard label="Total Leads" value={fmtInt(metrics.totalLeads)} sub={cplStatus.label} subColor={cplStatus.color} accent={COLORS.green} />
        <MetricCard label="Avg CPL" value={fmtMoney(metrics.avgCPL)} sub={cplStatus.label} subColor={cplStatus.color} accent={COLORS.amber} />
        <MetricCard label="Total Reach" value={fmtInt(metrics.totalReach)} sub="unique people" accent={COLORS.violet} />
        <MetricCard label="Impressions" value={fmtInt(metrics.totalImpressions)} sub="total views" accent={COLORS.cyan} />
        <MetricCard label="Calendly Leads" value={fmtInt(metrics.calendlyLeads)} sub="booked calls" accent={COLORS.blue} />
        <MetricCard label="SLP Leads" value={fmtInt(metrics.slpLeads)} sub="landing page" accent={COLORS.cyan} />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
        <MetricCard label="Avg LP Views" value={fmtInt(metrics.avgLPViews)} sub="per day" accent={COLORS.pink} />
        <MetricCard label="Days Active" value={fmtInt(metrics.daysActive)} sub={`of ${dailyData.length} total`} accent={COLORS.violet} />
        <MetricCard
          label="Highest CPL"
          value={metrics.worstCPLPeriod ? fmtMoney(metrics.worstCPL) : "—"}
          sub={metrics.worstCPLPeriod ? metrics.worstCPLPeriod.label : ""}
          subColor={COLORS.red}
          accent={COLORS.red}
        />
      </div>

      {/* charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 rounded-xl p-4" style={{ backgroundColor: COLORS.panel, border: `1px solid ${COLORS.border}` }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold" style={{ color: COLORS.textPrimary }}>
              Spend &amp; Leads by Period
            </span>
            <span className="text-xs" style={{ color: COLORS.textFaint, fontFamily: MONO }}>
              {effectiveBucket === 1 ? "daily" : `every ${effectiveBucket} days`}
            </span>
          </div>
          <div className="flex items-center gap-4 mb-2">
            <div className="flex items-center gap-1.5 text-xs" style={{ color: COLORS.textSecondary }}>
              <span style={{ width: 10, height: 10, backgroundColor: COLORS.blue, borderRadius: 2, display: "inline-block" }} />
              Spend ($)
            </div>
            <div className="flex items-center gap-1.5 text-xs" style={{ color: COLORS.textSecondary }}>
              <span style={{ width: 14, height: 2, backgroundColor: COLORS.cyan, display: "inline-block" }} />
              Total Leads
            </div>
          </div>
          <div style={{ width: "100%", height: 340 }}>
            <ResponsiveContainer>
              <ComposedChart data={buckets} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <CartesianGrid stroke={COLORS.borderSoft} strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: COLORS.textFaint }}
                  interval={Math.max(0, Math.floor(buckets.length / 10))}
                  angle={-35}
                  textAnchor="end"
                  height={55}
                  axisLine={{ stroke: COLORS.borderSoft }}
                  tickLine={false}
                />
                <YAxis yAxisId="left" tick={{ fontSize: 11, fill: COLORS.textFaint }} axisLine={false} tickLine={false} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: COLORS.textFaint }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: COLORS.panelAlt, border: `1px solid ${COLORS.border}`, borderRadius: 8, fontSize: 12 }}
                  labelStyle={{ color: COLORS.textSecondary }}
                  itemStyle={{ color: COLORS.textPrimary }}
                />
                <Bar yAxisId="left" dataKey="spend" fill={COLORS.blue} radius={[3, 3, 0, 0]} name="Spend ($)" maxBarSize={28} />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="leads"
                  stroke={COLORS.cyan}
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: COLORS.cyan, strokeWidth: 0 }}
                  activeDot={{ r: 5 }}
                  name="Total Leads"
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl p-4 flex flex-col" style={{ backgroundColor: COLORS.panel, border: `1px solid ${COLORS.border}` }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold" style={{ color: COLORS.textPrimary }}>
              Lead Type Split
            </span>
            <span className="text-xs" style={{ color: COLORS.textFaint, fontFamily: MONO }}>
              Calendly vs SLP
            </span>
          </div>
          <div style={{ width: "100%", height: 230, position: "relative" }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={62} outerRadius={92} paddingAngle={3} stroke="none">
                  {pieData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: COLORS.panelAlt, border: `1px solid ${COLORS.border}`, borderRadius: 8, fontSize: 12 }}
                  itemStyle={{ color: COLORS.textPrimary }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div
              style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", textAlign: "center", pointerEvents: "none" }}
            >
              <div className="font-bold" style={{ color: COLORS.textPrimary, fontSize: 22 }}>
                {fmtInt(metrics.totalLeads)}
              </div>
              <div className="uppercase tracking-wider" style={{ color: COLORS.textFaint, fontFamily: MONO, fontSize: 9 }}>
                total leads
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2 mt-3">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5" style={{ color: COLORS.textSecondary }}>
                <span style={{ width: 10, height: 10, backgroundColor: COLORS.blue, borderRadius: 2, display: "inline-block" }} />
                Calendly Leads
              </div>
              <span className="font-semibold" style={{ color: COLORS.textPrimary }}>
                {fmtInt(metrics.calendlyLeads)}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5" style={{ color: COLORS.textSecondary }}>
                <span style={{ width: 10, height: 10, backgroundColor: COLORS.cyan, borderRadius: 2, display: "inline-block" }} />
                SLP Leads
              </div>
              <span className="font-semibold" style={{ color: COLORS.textPrimary }}>
                {fmtInt(metrics.slpLeads)}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="text-xs mt-4" style={{ color: COLORS.textFaint }}>
        CSV columns auto-detected: Date, Spend, Leads, Calendly Leads, SLP Leads, Reach, Impressions, LP Views (one row per day; names matched loosely, case-insensitive). Use "Group by" to view the chart as daily, 2-day, 3-day, weekly, or any custom period — totals always reflect your selected date range.
      </div>
    </div>
  );
}
